package myWingsProjekt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static ArtikelList artikelList = new ArtikelList();

    public static void main(String[] args) {
        // write your code here

//            ArrayList<String[]> newList = null;
            String line = "";
            String splitBy = ",";
            try {
//parsing a CSV file into BufferedReader class constructor
                BufferedReader br = new BufferedReader(new FileReader("src/myWingsProjekt/attachments/Artikel.csv"));
                System.out.println("Nr.  " +"Name           " + "Menge     " + "Preis");
                while ((line = br.readLine()) != null)   //returns a Boolean value
                {

                    String[] artikelLine = line.split(splitBy);    // use comma as separator
//                    int nummer = Integer.parseInt(artikelLine[0]);
//                    String name = artikelLine[1];
//                    Float preis = Float.parseFloat(artikelLine[3]);
//                    int menge = Integer.parseInt(artikelLine[2]);

                    System.out.println(artikelLine[0] + " " + artikelLine[1] + "            " + artikelLine[2] + "     " + artikelLine[3]);
//                    artikelList.addNeuerArtikel(nummer, name, preis, menge );
//                    newList.add(new String[]{artikelLine[0], artikelLine[1], artikelLine[2], artikelLine[3]});
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        artikelList.addNeuerArtikel(511, "Kopierpapier",4.99,60);
        artikelList.addNeuerArtikel(471, "Maus", 9.99, 5 );


        int opt;
        boolean quit = false;
        printInstructions();
        Scanner scan = new Scanner(System.in);
        while (!quit) {

            opt = scan.nextInt();

            switch (opt) {
                case 1:
                    artikelList.printAlleArtikel();
                    break;
                case 2:
                    System.out.println("Was wollen Sie verkaufen ?");


                    break;
                case 3:
                    System.out.println("Was wollen Sie kaufen ?");
                    break;
                case 4:
                    artikelList.sortierenNachNummer();
                    System.out.println("die Artikel wurden nach der Nummer sortiert");
                    artikelList.printAlleArtikel();
                    break;
                case 5:
//                    artikelList.sortierenNachNamen();
                    System.out.println("die Artikel wurden nach dem Namen sortiert");
                    artikelList.printAlleArtikel();
                    break;
                case 6:
                    artikelList.sortierenNachMenge();
                    System.out.println("die Artikel wurden nach der Menge sortiert");
                    artikelList.printAlleArtikel();
                    break;
                case 7:
                    artikelList.sortierenNachPreis();
                    System.out.println("die Artikel wurden nach dem Preis sortiert");
                    artikelList.printAlleArtikel();
                    break;
//                    add new article
                case 8:
                    System.out.println("Bitte tragen Sie die Nummer ein");
                    int nan = scanner.nextInt();
                    System.out.println("Bitte tragen Sie den Name ein");
                    String nn = scanner.nextLine();
                    System.out.println("Bitte tragen Sie die Menge ein");
                    int nmg = scanner.nextInt();
                    System.out.println("Bitte tragen Sie den Preis ein");
                    float npr = scanner.nextFloat();

                    artikelList.addNeuerArtikel(nan,nn,npr,nmg);
                    System.out.println("die Artikel wurden sortiert");
                    artikelList.printAlleArtikel();
                    break;

                case 0:
                    quit = true;
                    break;
            }
        }
    }


    public static void printInstructions() {
        System.out.println();
        System.out.println("Bestandverwaltung");
        System.out.println("=================================");
        System.out.println();
        System.out.println(" 1 - Alle Artikel anzeigen");
        System.out.println(" 2 - Verkaufen");
        System.out.println(" 3 - Einkaufen");
        System.out.println(" 4 - Sortieren nach der Nummer");
        System.out.println(" 5 - Sortieren nach dem Namen");
        System.out.println(" 6 - Sortieren nach der Menge");
        System.out.println(" 7 - Sortieren nach dem Preis");
        System.out.println(" 8 - Neuer Artikel");
        System.out.println(" 0 - Einkaufen");

        System.out.println("Ihre Wahl?");
    }
    public static void printAlleArtikel(BestandsArtikel[] aba) {
        System.out.println("Nr. " + "Name " + "Menge" + "Preis" + "Lagerwert" );
        for (int i=0; i<aba.length;i++) {
            System.out.println(aba[i].getArtikelNummer() + aba[i].getName() + aba[i].getMenge() + aba[i].getPreis() + aba[i].getGesamtWert());
        }
    }


//    Es ist nicht benutzt
//
//    public static BestandsArtikel[]  sortierenNachNummer(BestandsArtikel[] abaSort) {
//        BestandsArtikel temp;
//        boolean sorted = false;
//        while (!sorted) {
//            sorted = true;
//            for (int i = 0; i < abaSort.length-1; i++) {
//                if (abaSort[i].getArtikelNummer() > abaSort[i+1].getArtikelNummer()) {
//                    temp = abaSort[i];
//                    abaSort[i] = abaSort[i+1];
//                    abaSort[i+1] = temp;
//                    sorted = false;
//                }
//            }
//        }
//        return abaSort;
//    }



}
