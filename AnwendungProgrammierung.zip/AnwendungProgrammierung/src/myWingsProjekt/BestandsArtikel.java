package myWingsProjekt;

public class BestandsArtikel extends Artikel {

    public BestandsArtikel(int an, String nm, double pr, int mg) {
        super(an, nm, pr);
        menge = mg;
        gesamtWert = mg*pr;
    }
    private int menge;
    private double gesamtWert;

    public int getMenge() {
        return menge;
    }

    public void setMenge(int menge) {
        this.menge = menge;
    }

    public double getGesamtWert() {
        return gesamtWert;
    }

}
