package myWingsProjekt;

import java.util.ArrayList;

public class ArtikelList {
    private ArrayList<BestandsArtikel> artikelList;


    public ArtikelList() {
        this.artikelList = new ArrayList<BestandsArtikel>();
    }

    public ArrayList<BestandsArtikel> getArtikelList() {
        return artikelList;
    }

    public void printAlleArtikel() {
        System.out.println("Nr. " + "Name " + "Menge" + "Preis" + "Lagerwert" );
        for (int i=0; i<artikelList.size();i++) {
            System.out.println(artikelList.get(i).getArtikelNummer() + artikelList.get(i).getName() + artikelList.get(i).getMenge() +
                    artikelList.get(i).getPreis() +" " + artikelList.get(i).getGesamtWert()+ " ");
        }
    }
    public void addNeuerArtikel(int artikelNummer, String name, double preis, int menge) {
        BestandsArtikel bestandsArtikel = new BestandsArtikel(artikelNummer, name, preis, menge);
        artikelList.add(bestandsArtikel);
    }

    public ArrayList<BestandsArtikel> sortierenNachNummer() {
        BestandsArtikel temp;
        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < artikelList.size()-1; i++) {
                if (artikelList.get(i).getArtikelNummer() > artikelList.get(i+1).getArtikelNummer()) {
                    temp = artikelList.get(i);
                    artikelList.set(i, artikelList.get(i+1));
                    artikelList.set(i+1, temp);
                    sorted = false;
                }
            }
        }
        return artikelList;
    }

    public ArrayList<BestandsArtikel> sortierenNachMenge() {
        BestandsArtikel temp;
        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < artikelList.size()-1; i++) {
                if (artikelList.get(i).getMenge() > artikelList.get(i+1).getMenge()) {
                    temp = artikelList.get(i);
                    artikelList.set(i, artikelList.get(i+1));
                    artikelList.set(i+1, temp);
                    sorted = false;
                }
            }
        }
        return artikelList;
    }
    public ArrayList<BestandsArtikel> sortierenNachPreis() {
        BestandsArtikel temp;
        boolean sorted = false;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < artikelList.size()-1; i++) {
                if (artikelList.get(i).getPreis() > artikelList.get(i+1).getPreis()) {
                    temp = artikelList.get(i);
                    artikelList.set(i, artikelList.get(i+1));
                    artikelList.set(i+1, temp);
                    sorted = false;
                }
            }
        }
        return artikelList;
    }
}
