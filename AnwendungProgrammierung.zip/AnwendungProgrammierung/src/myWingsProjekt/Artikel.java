package myWingsProjekt;

public class Artikel {
    private int artikelNummer;
    private String name;
    private double preis;

    public Artikel(int an, String nm, double pr) {
        artikelNummer = an;
        name = nm;
        preis = pr;
    }

    public int getArtikelNummer() {
        return artikelNummer;
    }

    public void setArtikelNummer(int artikelnummer) {
        this.artikelNummer = artikelnummer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPreis() {
        return preis;
    }

    public void setPreis(double preis) {
        this.preis = preis;
    }
}
