package myWingsProjekt;

public class Lager
{
    private String adresse;
    private BestandsArtikel[] bestandsartikel;

    /* Konstruktor */
    public Lager(BestandsArtikel[] ba)
    {
        bestandsartikel=ba;
    }

    public double getArtikelpreis(int artikelNummer)
    {
        for(int lauf=0;lauf<bestandsartikel.length;lauf++)
        {
            if(artikelNummer==bestandsartikel[lauf].getArtikelNummer())
                return bestandsartikel[lauf].getPreis();
        }

        return 1000000F;
    }

}

